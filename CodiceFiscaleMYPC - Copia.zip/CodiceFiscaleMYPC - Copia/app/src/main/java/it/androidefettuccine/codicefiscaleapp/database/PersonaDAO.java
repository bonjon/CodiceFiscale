package it.androidefettuccine.codicefiscaleapp.database;

import android.os.Parcel;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Dao
public interface PersonaDAO {
    @Query("SELECT * from persona")
    List<Persona> getAll();

    @Query("SELECT CF FROM persona")
    List<String> loadCodes();

    @Query("SELECT * FROM persona WHERE CF==:code")
    List<Persona> getSamePeople(String code);

    @Query("SELECT * FROM persona WHERE CF==:code")
    Persona getPerson(String code);

    @Query("SELECT nome FROM persona WHERE CF==:code")
    String getName(String code);

    @Query("SELECT cognome FROM persona WHERE CF==:code")
    String getLastName(String code);

    @Query("SELECT dataNascita FROM persona WHERE CF==:code")
    String getBirth(String code);


    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(Persona persona);

    //@Delete
    //void deleteUsers(List<Persona> persone);

    @Delete
    void deleteUser(Persona persona);
}
