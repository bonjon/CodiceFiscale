package it.androidefettuccine.codicefiscaleapp.exceptions;

public class ComuneNonValidoException extends Throwable {
    public ComuneNonValidoException(String string) {
        super(string);
    }
}
