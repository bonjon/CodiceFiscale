package it.androidefettuccine.codicefiscaleapp.activities;

import android.content.Intent;


import android.os.Bundle;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.LinearLayout;
import android.widget.TextView;


import androidx.annotation.NonNull;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import java.util.List;


import it.androidefettuccine.codicefiscaleapp.R;

import it.androidefettuccine.codicefiscaleapp.database.PersonaDatabase;

import it.androidefettuccine.codicefiscaleapp.utils.Reduced_Person;
import it.androidefettuccine.codicefiscaleapp.utils.SetAlternateCol;


public class Favourites extends AppCompatActivity {
    public PersonaDatabase db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.favourites);
        setTitle(getString(R.string.preferiti));



        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        RecyclerView recyclerView = findViewById(R.id.rvFavourites);
        RecyclerView.Adapter mAdapter = new FavouritesAdapter(createPerson());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(mAdapter);
    }


    public List<Reduced_Person> createPerson() {
        int i = 0;

        List<String> fiscalCode;
        String firstName, lastName, fullName;
        Reduced_Person cf_fullName;
        Reduced_Person couple;

        db = PersonaDatabase.getInstance(getApplicationContext());

        fiscalCode = db.personaDAO().loadCodes();
        System.out.println(fiscalCode);

        List<Reduced_Person> peopleList = new ArrayList<>();

        /*ciclo while per riempire peopleList di oggetti di tipo Reduced_Person*/
        while (i < fiscalCode.size()) {
            String cF = fiscalCode.get(i);
            System.out.println(cF);
            firstName = db.personaDAO().getName(cF);
            lastName = db.personaDAO().getLastName(cF);
            fullName = firstName + " " + lastName;
            cf_fullName = new Reduced_Person(cF, fullName);
            couple = cf_fullName.giveMePerson(cF, fullName);
            peopleList.add(couple);


            i++;
        }



        return peopleList;
    }


    /*Adapter per la RecyclerView */
    public class FavouritesAdapter extends RecyclerView.Adapter<FavouritesAdapter.Holder> implements View.OnClickListener {
        List<Reduced_Person> mDataset;
        Reduced_Person selectedPerson;


        FavouritesAdapter(List<Reduced_Person> myDataset) {
            mDataset = myDataset;
        }

        @NonNull
        @Override
        public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            ConstraintLayout cl = (ConstraintLayout) LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.row_favourites, parent, false);

            cl.setOnClickListener(this);


            return new Holder(cl);
        }

        @Override
        public void onBindViewHolder(@NonNull Holder holder, int position) {
            selectedPerson = mDataset.get(position);
            holder.tvPersonName.setText(selectedPerson.giveMeName());



            /*settaggio del colore alternato delle righe della RecyclerView sfruttando l' istanziazione
            di un oggetto della classe SetAlternateCol che agisce sulle righe pari*/
            SetAlternateCol itemView = new SetAlternateCol(holder.itemView);
            itemView.setColor(position,holder.itemView);



        }




        @Override
        public int getItemCount() {
            return mDataset.size();
        }

        @Override
        public void onClick(View v) {

            /*Chiamo person_object l' oggetto di tipo Reduced_Person corrispondente alla riga
             selezionata*/
            int position = ((RecyclerView) v.getParent()).getChildAdapterPosition(v);
            Reduced_Person person_object = mDataset.get(position);

            /*Intent per lanciare l' activity Detail passandogli,tramite bundle,l' oggetto
            selezionato dall' utente*/
            Intent i = new Intent(Favourites.this, Detail.class);
            i.putExtra("Selected_Person", person_object);
            startActivity(i);
        }

        class Holder extends RecyclerView.ViewHolder {
            private TextView tvPersonName;



            Holder(ConstraintLayout cl) {
                super(cl);
                tvPersonName = cl.findViewById(R.id.tvPersonName);





            }



        }
    }
}



