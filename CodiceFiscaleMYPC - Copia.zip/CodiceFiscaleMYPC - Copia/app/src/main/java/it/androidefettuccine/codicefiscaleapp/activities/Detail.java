package it.androidefettuccine.codicefiscaleapp.activities;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.BarcodeEncoder;

import java.util.List;

import it.androidefettuccine.codicefiscaleapp.R;
import it.androidefettuccine.codicefiscaleapp.database.Persona;
import it.androidefettuccine.codicefiscaleapp.database.PersonaDatabase;
import it.androidefettuccine.codicefiscaleapp.fragments.FragmentCode;
import it.androidefettuccine.codicefiscaleapp.fragments.FragmentDeletion;
import it.androidefettuccine.codicefiscaleapp.utils.Reduced_Person;

public class Detail extends AppCompatActivity {
    public PersonaDatabase db;
    public Reduced_Person selPerson;
    String fiscalCode;
    String person_name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {



        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail);
        setTitle(getString(R.string.preferiti));



        /*Prendo con la getParcelableExtra l'oggetto selPerson di tipo Reduced_Person
        per ottenere la stringa Nome-Cognome e la stringa del codice fiscale*/
        Intent intent = getIntent();
        selPerson = intent.getParcelableExtra("Selected_Person");

        fiscalCode = selPerson.giveMeCode();
        person_name = selPerson.giveMeName();

        try {
            Holder holder = new Holder();
        } catch (WriterException e) {
            e.printStackTrace();
        }


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_detail, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        /*Si apre il menu e si clicca su about*/
        if (item.getItemId() == R.id.itemCestino) {


            Bundle bundle = new Bundle();
            bundle.putParcelable("persona", selPerson);
            FragmentDeletion fragment = new FragmentDeletion();
            fragment.setArguments(bundle);
            fragment.show(getSupportFragmentManager(), "Fragment");


        }
        return true;
    }

    class Holder implements View.OnClickListener {

        TextView tvFiscalCode;
        TextView tvFullName;
        ImageView ivCard;
        TextView tvCF;
        TextView tvName;
        TextView tvSurname;
        TextView tvDate;
        ImageView ivBarcode;
        ImageView ivBigBarcode;

        public Holder() throws WriterException{

            db = PersonaDatabase.getInstance(getApplicationContext());

            tvFiscalCode = findViewById(R.id.tvFiscalCode);
            tvFullName = findViewById(R.id.tvFullName);
            ivCard = findViewById(R.id.ivCard);
            tvName = findViewById(R.id.tvName);
            tvSurname = findViewById(R.id.tvSurname);
            tvDate = findViewById(R.id.tvDate);
            tvCF = findViewById(R.id.tvCF);
            ivBarcode = findViewById(R.id.ivBarcode);
            ivBigBarcode = findViewById(R.id.ivBigBarcode);

            tvFiscalCode.setText(fiscalCode);

            /*nel caso la stringa del Nome-Cognome proveniente da selPerson sia troppo lunga
            chiamiamo il database per pescare separatamente Nome e Cognome */
            if(person_name.length()<26) {
                tvFullName.setText(person_name);
            }
            else{

                String short_name=db.personaDAO().getName(fiscalCode);
                if(short_name.length()>10) {short_name = short_name.substring(0,10) + " " + "...";}
                String short_lastName=db.personaDAO().getLastName(fiscalCode);
                if(short_lastName.length()>10) {short_lastName = short_lastName.substring(0,10)+" "+"...";}
                String short_fullName = short_name+"  "+short_lastName;
                tvFullName.setText((short_fullName));

            }

            tvName.setText(db.personaDAO().getName(fiscalCode));
            tvSurname.setText(db.personaDAO().getLastName(fiscalCode));
            tvDate.setText((db.personaDAO().getBirth(fiscalCode)));
            tvCF.setText(fiscalCode);

            generateCode(fiscalCode,ivBigBarcode);
            generateCode(fiscalCode,ivBarcode);
        }

        /*Funzione che genera il barcode in bitmap corrispondente al codice fiscale calcolato
        utilizzando la libreria stand-alone Zxing, tipo di barcode Code39*/
        void generateCode(String value, ImageView iv) throws WriterException {
                com.google.zxing.MultiFormatWriter writer = new MultiFormatWriter();
                BitMatrix bm = writer.encode(value, BarcodeFormat.CODE_39, 250, 50); //Code39
                BarcodeEncoder barcodeEncoder = new BarcodeEncoder();
                Bitmap bitmap = barcodeEncoder.createBitmap(bm);
                iv.setImageBitmap(bitmap);
            }





        @Override
        public void onClick(View v) {


        }
    }
}
