package it.androidefettuccine.codicefiscaleapp.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import java.util.List;

import it.androidefettuccine.codicefiscaleapp.R;
import it.androidefettuccine.codicefiscaleapp.activities.Detail;
import it.androidefettuccine.codicefiscaleapp.activities.Favourites;
import it.androidefettuccine.codicefiscaleapp.activities.MainActivity;
import it.androidefettuccine.codicefiscaleapp.database.Persona;
import it.androidefettuccine.codicefiscaleapp.database.PersonaDatabase;
import it.androidefettuccine.codicefiscaleapp.utils.Reduced_Person;

public class FragmentDeletion extends DialogFragment {
    PersonaDatabase db;
    String code;
    public Reduced_Person selPerson;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);


        db = PersonaDatabase.getInstance(getContext());
        assert getArguments() != null;

        selPerson = getArguments().getParcelable("persona");
        View v = inflater.inflate(R.layout.fragment_delete, container, false);
        return v;
    }

    class Holder implements View.OnClickListener {

        public Holder(View v) {

            TextView tvDeleteUserConfirm;
            TextView tvUserDeleted;
            TextView tvQuestion;
            Button btnSi;
            Button btnNo;

            tvDeleteUserConfirm = v.findViewById(R.id.tvDeleteUserConfirm);
            tvUserDeleted = v.findViewById(R.id.tvUserDeleted);
            tvQuestion = v.findViewById(R.id.tvQuestion);
            btnNo = v.findViewById(R.id.btnNo);
            btnSi = v.findViewById(R.id.btnSi);

            String name = selPerson.giveMeName();


            tvUserDeleted.setText(name);

            btnNo.setOnClickListener(this);
            btnSi.setOnClickListener(this);


        }


        @Override
        public void onClick(View v) {

            if (v.getId() == R.id.btnSi) {


                if (db.personaDAO().getAll()==null){
                    Toast.makeText(getActivity(), R.string.no_save_codes, Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(getActivity(), MainActivity.class);
                    startActivity(intent);
                }
                else{
                    String code = selPerson.giveMeCode();
                    Persona dbResult = db.personaDAO().getPerson(code);
                    db.personaDAO().deleteUser(dbResult);
                    Intent intent = new Intent(getActivity(), Favourites.class);
                    startActivity(intent);
                }



            }
            if (v.getId() == R.id.btnNo) {
                assert getFragmentManager() != null;
                getFragmentManager().beginTransaction().remove(FragmentDeletion.this).commit();
            }
        }
    }
}