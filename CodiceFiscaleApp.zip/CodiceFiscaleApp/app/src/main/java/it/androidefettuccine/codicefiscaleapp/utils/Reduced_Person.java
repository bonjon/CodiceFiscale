package it.androidefettuccine.codicefiscaleapp.utils;

import android.os.Parcel;
import android.os.Parcelable;

public class Reduced_Person implements Parcelable {

    private final String code;
    private final String full_name;

    public Reduced_Person(String code, String full_name) {
        this.code = code;
        this.full_name=full_name;
    }

    public Reduced_Person giveMePerson(String code, String full_name){
        Reduced_Person person = new Reduced_Person(code, full_name);
        return person;
    }

    public String giveMeCode (){
        return Reduced_Person.this.code;
    }

    public String giveMeName (){
        return Reduced_Person.this.full_name;
    }


    /*metodi per rendere l' oggetto "Reduced_Person" parcelable*/

    public Reduced_Person(Parcel in){
        String[] data = new String[2];

        in.readStringArray(data);

        this.code = data[0];
        this.full_name = data[1];
    }

    public static final Parcelable.Creator<Reduced_Person> CREATOR = new Parcelable.Creator<Reduced_Person>() {
        @Override
        public Reduced_Person createFromParcel(Parcel in) {
            return new Reduced_Person(in);
        }

        @Override
        public Reduced_Person[] newArray(int size) {
            return new Reduced_Person[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeStringArray(new String[] {this.code,this.full_name});
    }



}

