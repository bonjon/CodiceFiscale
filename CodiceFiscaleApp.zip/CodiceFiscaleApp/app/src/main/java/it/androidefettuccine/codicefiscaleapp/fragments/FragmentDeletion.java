package it.androidefettuccine.codicefiscaleapp.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import it.androidefettuccine.codicefiscaleapp.R;
import it.androidefettuccine.codicefiscaleapp.activities.Favourites;
import it.androidefettuccine.codicefiscaleapp.activities.MainActivity;
import it.androidefettuccine.codicefiscaleapp.database.Persona;
import it.androidefettuccine.codicefiscaleapp.database.PersonaDatabase;
import it.androidefettuccine.codicefiscaleapp.utils.Reduced_Person;

public class FragmentDeletion extends DialogFragment {
    private PersonaDatabase db;
    private Reduced_Person selPerson;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);


        db = PersonaDatabase.getInstance(getContext());
        assert getArguments() != null;

        selPerson = getArguments().getParcelable("persona");
        View v = inflater.inflate(R.layout.fragment_delete, container, false);
        new Holder(v);
        return v;
    }

    class Holder implements View.OnClickListener {
        TextView tvDeleteUserConfirm;
        TextView tvUserDeleted;
        TextView tvQuestion;
        Button btnSi;
        Button btnNo;

        Holder(View v) {

            tvDeleteUserConfirm = v.findViewById(R.id.tvDeleteUserConfirm);
            tvUserDeleted = v.findViewById(R.id.tvUserDeleted);
            tvQuestion = v.findViewById(R.id.tvQuestion);
            btnNo = v.findViewById(R.id.btnNo2);
            btnSi = v.findViewById(R.id.btnSi2);

            String name = selPerson.giveMeName();


            tvUserDeleted.setText(name);
            System.out.println(tvUserDeleted.toString());
            btnNo.setOnClickListener(this);
            btnSi.setOnClickListener(this);


        }


        @Override
        public void onClick(View v) {

            if (v.getId() == R.id.btnSi2) {


                if (db.personaDAO().getAll().size() == 1) {
                    String code = selPerson.giveMeCode();
                    Toast.makeText(getActivity(), R.string.no_save_codes, Toast.LENGTH_SHORT).show();
                    Persona dbResult = db.personaDAO().getPerson(code);
                    db.personaDAO().deleteUser(dbResult);
                    Intent intent = new Intent(getActivity(), MainActivity.class);
                    startActivity(intent);
                } else {
                    String code = selPerson.giveMeCode();
                    Toast.makeText(getActivity(), R.string.cancellato ,Toast.LENGTH_LONG).show();
                    Persona dbResult = db.personaDAO().getPerson(code);
                    db.personaDAO().deleteUser(dbResult);
                    assert getFragmentManager() != null;
                    getFragmentManager().beginTransaction().remove(FragmentDeletion.this).commit();
                    Intent intent = new Intent(getActivity(), Favourites.class);
                    startActivity(intent);
                }


            }
            if (v.getId() == R.id.btnNo2) {
                assert getFragmentManager() != null;
                getFragmentManager().beginTransaction().remove(FragmentDeletion.this).commit();
            }
        }
    }
}