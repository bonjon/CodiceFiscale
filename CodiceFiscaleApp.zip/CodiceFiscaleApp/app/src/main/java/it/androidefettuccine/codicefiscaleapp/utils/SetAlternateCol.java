package it.androidefettuccine.codicefiscaleapp.utils;

import android.graphics.Color;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class SetAlternateCol extends RecyclerView.ViewHolder {

    public SetAlternateCol(@NonNull View itemView) {
        super(itemView);

    }

    public void setColor(int position, View itemView){
        if(position%2==0){
            itemView.setBackgroundColor(Color.LTGRAY);
        }
    }
}
