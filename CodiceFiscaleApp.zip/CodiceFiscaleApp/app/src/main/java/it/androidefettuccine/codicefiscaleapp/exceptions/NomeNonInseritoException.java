package it.androidefettuccine.codicefiscaleapp.exceptions;

public class NomeNonInseritoException extends Exception {
    public NomeNonInseritoException(String name) {
        super(name);
    }
}
