package it.giovannipica.cocktailapplication.activities;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.List;

import it.giovannipica.cocktailapplication.R;
import it.giovannipica.cocktailapplication.database.AppCocktailDatabase;
import it.giovannipica.cocktailapplication.database.Cocktail;

public class CocktailActivity extends AppCompatActivity {

    private AppCocktailDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        createDB();
        new Holder();
    }
    /*create databse with Room*/
    private void createDB(){
        db = Room.databaseBuilder(getApplicationContext(),AppCocktailDatabase.class,"cocktail.db").allowMainThreadQueries().build();
    }

    abstract class VolleyCocktail implements Response.ErrorListener, Response.Listener<String> {
        abstract void fill(List<Cocktail> cnt);

        private static final String APIKEY = "1";
        void searchCocktailById(String id) {
            String url = "https://www.thecocktaildb.com/api/json/v1/%s/lookup.php?i=%s";
            url = String.format(url, APIKEY, id);
            apiCall(url);
        }

        void searchCocktailsByName(String s) {
            String url = "https://www.thecocktaildb.com/api/json/v1/1/search.php?s=%s";
            url = String.format(url, s);
            apiCall(url);
        }

        void searchCocktailsByIngredient(String i) {
            String url = "https://www.thecocktaildb.com/api/json/v1/1/filter.php?i=%s";
            url = String.format(url, i);
            apiCall(url);
        }

        private void apiCall(String url) {
            RequestQueue requestQueue;
            requestQueue = Volley.newRequestQueue(CocktailActivity.this);
            StringRequest stringRequest = new StringRequest(Request.Method.GET,
                    url,
                    this,
                    this);
            requestQueue.add(stringRequest);

        }

        @Override
        public void onErrorResponse(VolleyError error) {
            Toast.makeText(CocktailActivity.this,"Something goes wrong",Toast.LENGTH_LONG).show();
        }

        @Override
        public void onResponse(String response) {
            Gson gson = new Gson();
            String drinks;
            try {
                JSONObject jsonObject = new JSONObject(response);
                drinks = jsonObject.getJSONArray("drinks").toString();
                Type listType = new TypeToken<List<Cocktail>>() {
                }.getType();
                List<Cocktail> cnt = gson.fromJson(drinks, listType);
                if (cnt != null && cnt.size() > 0) {
                    Log.w("CA", "" + cnt.size());
                    db.cocktailDAO().insertAll(cnt);
                    fill(cnt);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    class Holder implements View.OnClickListener, TextView.OnEditorActionListener {
        final Button btnSearch;
        final RecyclerView rvCocktails;
        final EditText etSearch;
        final VolleyCocktail model;

        Holder() {
            btnSearch = findViewById(R.id.btnSearch);
            rvCocktails = findViewById(R.id.rvCocktails);
            etSearch = findViewById(R.id.etSearch);

            btnSearch.setOnClickListener(this);
            etSearch.setOnEditorActionListener(this);
            this.model = new VolleyCocktail() {
                @Override
                void fill(List<Cocktail> cnt) {
                    Log.w("CA", "fill");
                    fillList(cnt);
                }

                private void fillList(List<Cocktail> cnt) {
                    RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(CocktailActivity.this);
                    rvCocktails.setLayoutManager(layoutManager);
                    CocktailAdapter mAdapter = new CocktailAdapter(cnt);
                    rvCocktails.setAdapter(mAdapter);
                }
            };
        }

        @Override
        public void onClick(View v) {
            String search = etSearch.getText().toString();
            model.searchCocktailsByName(search);
            hideKeyboard(CocktailActivity.this);
        }

        void hideKeyboard(Activity activity) {
            InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
            //Find the currently focused view, so we can grab the correct window token from it.
            View view = activity.getCurrentFocus();
            //If no view currently has focus, create a new one, just so we can grab a window token from it
            if (view == null) {
                view = new View(activity);
            }
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }

        @Override
        public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                String search = etSearch.getText().toString();
                model.searchCocktailsByName(search);
                return true;
            }
            return false;
        }

    }

    private class CocktailAdapter extends RecyclerView.Adapter<CocktailAdapter.Holder> implements View.OnClickListener {
        private final List<Cocktail> cocktails;

        CocktailAdapter(List<Cocktail> all) {
            cocktails = all;
        }

        @NonNull
        @Override
        public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            ConstraintLayout cl;
            cl = (ConstraintLayout) LayoutInflater
                    .from(parent.getContext())
                    .inflate(R.layout.layout_cocktail, parent, false);
            cl.setOnClickListener(this);
            return new Holder(cl);
        }

        @Override
        public void onBindViewHolder(@NonNull Holder holder, int position) {
            holder.tvDrink.setText(cocktails.get(position).strDrink);
            if (cocktails.get(position).strAlcoholic.compareTo("Alcoholic") == 0)
                holder.ivAlcoholic.setImageResource(R.drawable.ic_alcolico);
            else
                holder.ivAlcoholic.setImageResource(R.drawable.ic_noalcolico);
        }

        @Override
        public int getItemCount() {
            return cocktails.size();
        }

        @Override
        public void onClick(View v) {
            int position = ((RecyclerView) v.getParent()).getChildAdapterPosition(v);
            Cocktail cocktail = cocktails.get(position);
            Intent intent = new Intent(CocktailActivity.this, CocktailDetailActivity.class);
            intent.putExtra("cocktail", cocktail);
            CocktailActivity.this.startActivity(intent);
        }

        class Holder extends RecyclerView.ViewHolder {
            final TextView tvDrink;
            final ImageView ivAlcoholic;

            Holder(@NonNull View itemView) {
                super(itemView);
                tvDrink = itemView.findViewById(R.id.tvDrink);
                ivAlcoholic = itemView.findViewById(R.id.ivAlcoholic);
            }
        }
    }
}
