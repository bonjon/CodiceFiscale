package it.giovannipica.cocktailapplication.activities;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.Volley;

import org.jetbrains.annotations.NotNull;

import it.giovannipica.cocktailapplication.R;
import it.giovannipica.cocktailapplication.database.Cocktail;

public class CocktailDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent data = getIntent();
        Cocktail cocktail = data.getParcelableExtra("cocktail") ;
        setContentView(R.layout.activity_cocktail_detail);
        setTitle(cocktail.strDrink);
        Holder holder = new Holder();
        holder.setTviews(cocktail);
        holder.setImages(cocktail);
    }


    class Holder{

        private ImageView ivThumb;
        private ImageView ivAlcoholic;

        private TextView tvIngredient1;
        private TextView tvIngredient2;
        private TextView tvIngredient3;
        private TextView tvIngredient4;
        private TextView tvIngredient5;
        private TextView tvIngredient6;
        private TextView tvIngredient7;
        private TextView tvIngredient8;
        private TextView tvIngredient9;
        private TextView tvIngredient10;
        private TextView tvIngredient11;
        private TextView tvIngredient12;
        private TextView tvIngredient13;
        private TextView tvIngredient14;
        private TextView tvIngredient15;

        private TextView tvInstructions;
        private TextView tvGlass;

        Holder(){

            /*Find ids of all textviews or imageviews*/
            ivThumb = findViewById(R.id.ivThumb);
            ivAlcoholic = findViewById(R.id.ivAlcoholic);

            tvIngredient1 = findViewById(R.id.tvIngredient1);
            tvIngredient2 = findViewById(R.id.tvIngredient2);
            tvIngredient3 = findViewById(R.id.tvIngredient3);
            tvIngredient4 = findViewById(R.id.tvIngredient4);
            tvIngredient5 = findViewById(R.id.tvIngredient5);
            tvIngredient6 = findViewById(R.id.tvIngredient6);
            tvIngredient7 = findViewById(R.id.tvIngredient7);
            tvIngredient8 = findViewById(R.id.tvIngredient8);
            tvIngredient9 = findViewById(R.id.tvIngredient9);
            tvIngredient10 = findViewById(R.id.tvIngredient10);
            tvIngredient11 = findViewById(R.id.tvIngredient11);
            tvIngredient12 = findViewById(R.id.tvIngredient12);
            tvIngredient13 = findViewById(R.id.tvIngredient13);
            tvIngredient14 = findViewById(R.id.tvIngredient14);
            tvIngredient15 = findViewById(R.id.tvIngredient15);

            tvInstructions = findViewById(R.id.tvInstructions);
            tvGlass = findViewById(R.id.tvGlass);
        }

        public void setIngredient(TextView tvIngredient, String measure, String ingredient){
            /*Function that sets the textviews in many cases*/
            String s = measure + "\n" + ingredient;
            if(ingredient==null)
                /*no ingredient*/
                tvIngredient.setText("");
            else if (measure == null)
                /*this is the case when measure is to taste*/
                tvIngredient.setText(ingredient);
            else
                /*ingredient and measure are present*/
                tvIngredient.setText(s);
        }

        public void setTviews(@NotNull Cocktail cocktail){
            /*Function that sets textviews*/
            tvInstructions.setText(cocktail.strInstructions);
            tvGlass.setText(cocktail.strGlass);

            setIngredient(tvIngredient1,cocktail.strMeasure1,cocktail.strIngredient1);
            setIngredient(tvIngredient2,cocktail.strMeasure2,cocktail.strIngredient2);
            setIngredient(tvIngredient3,cocktail.strMeasure3,cocktail.strIngredient3);
            setIngredient(tvIngredient4,cocktail.strMeasure4,cocktail.strIngredient4);
            setIngredient(tvIngredient5,cocktail.strMeasure5,cocktail.strIngredient5);
            setIngredient(tvIngredient6,cocktail.strMeasure6,cocktail.strIngredient6);
            setIngredient(tvIngredient7,cocktail.strMeasure7,cocktail.strIngredient7);
            setIngredient(tvIngredient8,cocktail.strMeasure8,cocktail.strIngredient8);
            setIngredient(tvIngredient9,cocktail.strMeasure9,cocktail.strIngredient9);
            setIngredient(tvIngredient10,cocktail.strMeasure10,cocktail.strIngredient10);
            setIngredient(tvIngredient11,cocktail.strMeasure11,cocktail.strIngredient11);
            setIngredient(tvIngredient12,cocktail.strMeasure12,cocktail.strIngredient12);
            setIngredient(tvIngredient13,cocktail.strMeasure13,cocktail.strIngredient13);
            setIngredient(tvIngredient14,cocktail.strMeasure14,cocktail.strIngredient14);
            setIngredient(tvIngredient15,cocktail.strMeasure15,cocktail.strIngredient15);
        }

        public void setImages(@NotNull Cocktail cocktail){
            /*Function that sets images on the view*/
            String url = cocktail.strDrinkThumb; //save drink thumbnail
            imgCall(url); //ImageRequest
            /*Below the function sets image Alcoholic for alcoholic drinks and NoAlcoholic otherwise*/
            if(cocktail.strAlcoholic.compareTo("Alcoholic") == 0){
                ivAlcoholic.setImageResource(R.drawable.ic_alcolico);
            }
            else{
                ivAlcoholic.setImageResource(R.drawable.ic_noalcolico);
            }
        }

        private void imgCall(String url) {
            RequestQueue requestQueue;
            requestQueue = Volley.newRequestQueue(CocktailDetailActivity.this);
            ImageRequest stringRequest = new ImageRequest(url, new Response.Listener<Bitmap>() {
                @Override
                public void onResponse(Bitmap response) {
                    ivThumb.setImageBitmap(response);   //set ivThumb with the bitmap response
                }
            }, 0, 0,
                    ImageView.ScaleType.CENTER_CROP,
                    Bitmap.Config.RGB_565,
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(CocktailDetailActivity.this,"RESPONSE IMGREQUEST ERROR", Toast.LENGTH_LONG).show();
                        }
                    });
            requestQueue.add(stringRequest);
        }
    }
}
