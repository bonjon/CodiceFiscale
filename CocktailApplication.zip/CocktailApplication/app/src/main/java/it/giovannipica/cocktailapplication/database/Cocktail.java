package it.giovannipica.cocktailapplication.database;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.room.Entity;
import androidx.room.ColumnInfo;
import androidx.room.PrimaryKey;

    /*A Parcelable is the Android implementation of the Java Serializable. It assumes a certain structure and way of processing it.
    This way a Parcelable can be processed relatively fast, compared to the standard Java serialization.*/
    /*This is the cocktail entity class with its informations that we get in the site of cocktailDB*/
@Entity
public class Cocktail implements Parcelable {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name="_id")
    public int idDrink;
    @ColumnInfo(name="strDrink")
    public String strDrink;
    @ColumnInfo(name="strDrinkAlternate")
    public String strDrinkAlternate;
    @ColumnInfo(name="strTags")
    public String strTags;
    @ColumnInfo(name="strVideo")
    public String strVideo;
    @ColumnInfo(name="strCategory")
    public String strCategory;
    @ColumnInfo(name="strIBA")
    public String strIBA;
    @ColumnInfo(name="strAlcoholic")
    public String strAlcoholic;
    @ColumnInfo(name="strGlass")
    public String strGlass;
    @ColumnInfo(name="strInstructions")
    public String strInstructions;
    @ColumnInfo(name="strDrinkThumb")
    public String strDrinkThumb;
    @ColumnInfo(name="strIngredient1")
    public String strIngredient1;
    @ColumnInfo(name="strIngredient2")
    public String strIngredient2;
    @ColumnInfo(name="strIngredient3")
    public String strIngredient3;
    @ColumnInfo(name="strIngredient4")
    public String strIngredient4;
    @ColumnInfo(name="strIngredient5")
    public String strIngredient5;
    @ColumnInfo(name="strIngredient6")
    public String strIngredient6;
    @ColumnInfo(name="strIngredient7")
    public String strIngredient7;
    @ColumnInfo(name="strIngredient8")
    public String strIngredient8;
    @ColumnInfo(name="strIngredient9")
    public String strIngredient9;
    @ColumnInfo(name="strIngredient10")
    public String strIngredient10;
    @ColumnInfo(name="strIngredient11")
    public String strIngredient11;
    @ColumnInfo(name="strIngredient12")
    public String strIngredient12;
    @ColumnInfo(name="strIngredient13")
    public String strIngredient13;
    @ColumnInfo(name="strIngredient14")
    public String strIngredient14;
    @ColumnInfo(name="strIngredient15")
    public String strIngredient15;
    @ColumnInfo(name="strMeasure1")
    public String strMeasure1;
    @ColumnInfo(name="strMeasure2")
    public String strMeasure2;
    @ColumnInfo(name="strMeasure3")
    public String strMeasure3;
    @ColumnInfo(name="strMeasure4")
    public String strMeasure4;
    @ColumnInfo(name="strMeasure5")
    public String strMeasure5;
    @ColumnInfo(name="strMeasure6")
    public String strMeasure6;
    @ColumnInfo(name="strMeasure7")
    public String strMeasure7;
    @ColumnInfo(name="strMeasure8")
    public String strMeasure8;
    @ColumnInfo(name="strMeasure9")
    public String strMeasure9;
    @ColumnInfo(name="strMeasure10")
    public String strMeasure10;
    @ColumnInfo(name="strMeasure11")
    public String strMeasure11;
    @ColumnInfo(name="strMeasure12")
    public String strMeasure12;
    @ColumnInfo(name="strMeasure13")
    public String strMeasure13;
    @ColumnInfo(name="strMeasure14")
    public String strMeasure14;
    @ColumnInfo(name="strMeasure15")
    public String strMeasure15;
    @ColumnInfo(name="strCreativeCommonsConfirmed")
    public String strCreativeCommonsConfirmed;
    @ColumnInfo(name="dateModified")
    public String dateModified;
    /*To allow your custom object to be parsed to another component they need to implement the android.os.Parcelable interface.
    It must also provide a static final method called CREATOR which must implement the Parcelable.Creator interface. */
    public static final Creator<Cocktail> CREATOR = new Creator<Cocktail>() {
        @Override
        public Cocktail createFromParcel(Parcel in) {
            return new Cocktail(in);
        }

        @Override
        public Cocktail[] newArray(int size) {
            return new Cocktail[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(idDrink);
        dest.writeString(strDrink);
        dest.writeString(strDrinkAlternate);
        dest.writeString(strTags);
        dest.writeString(strVideo);
        dest.writeString(strCategory);
        dest.writeString(strIBA);
        dest.writeString(strAlcoholic);
        dest.writeString(strGlass);
        dest.writeString(strInstructions);
        dest.writeString(strDrinkThumb);
        dest.writeString(strIngredient1);
        dest.writeString(strIngredient2);
        dest.writeString(strIngredient3);
        dest.writeString(strIngredient4);
        dest.writeString(strIngredient5);
        dest.writeString(strIngredient6);
        dest.writeString(strIngredient7);
        dest.writeString(strIngredient8);
        dest.writeString(strIngredient9);
        dest.writeString(strIngredient10);
        dest.writeString(strIngredient11);
        dest.writeString(strIngredient12);
        dest.writeString(strIngredient13);
        dest.writeString(strIngredient14);
        dest.writeString(strIngredient15);
        dest.writeString(strMeasure1);
        dest.writeString(strMeasure2);
        dest.writeString(strMeasure3);
        dest.writeString(strMeasure4);
        dest.writeString(strMeasure5);
        dest.writeString(strMeasure6);
        dest.writeString(strMeasure7);
        dest.writeString(strMeasure8);
        dest.writeString(strMeasure9);
        dest.writeString(strMeasure10);
        dest.writeString(strMeasure11);
        dest.writeString(strMeasure12);
        dest.writeString(strMeasure13);
        dest.writeString(strMeasure14);
        dest.writeString(strMeasure15);
        dest.writeString(strCreativeCommonsConfirmed);
        dest.writeString(dateModified);
    }

    public Cocktail() {

    }

    private Cocktail(Parcel in) {
        idDrink = in.readInt();
        strDrink = in.readString();
        strDrinkAlternate = in.readString();
        strTags = in.readString();
        strVideo = in.readString();
        strCategory = in.readString();
        strIBA = in.readString();
        strAlcoholic = in.readString();
        strGlass = in.readString();
        strInstructions = in.readString();
        strDrinkThumb = in.readString();
        strIngredient1 = in.readString();
        strIngredient2 = in.readString();
        strIngredient3 = in.readString();
        strIngredient4 = in.readString();
        strIngredient5 = in.readString();
        strIngredient6 = in.readString();
        strIngredient7 = in.readString();
        strIngredient8 = in.readString();
        strIngredient9 = in.readString();
        strIngredient10 = in.readString();
        strIngredient11 = in.readString();
        strIngredient12 = in.readString();
        strIngredient13 = in.readString();
        strIngredient14 = in.readString();
        strIngredient15 = in.readString();
        strMeasure1 = in.readString();
        strMeasure2 = in.readString();
        strMeasure3 = in.readString();
        strMeasure4 = in.readString();
        strMeasure5 = in.readString();
        strMeasure6 = in.readString();
        strMeasure7 = in.readString();
        strMeasure8 = in.readString();
        strMeasure9 = in.readString();
        strMeasure10 = in.readString();
        strMeasure11 = in.readString();
        strMeasure12 = in.readString();
        strMeasure13 = in.readString();
        strMeasure14 = in.readString();
        strMeasure15 = in.readString();
        strCreativeCommonsConfirmed = in.readString();
        dateModified = in.readString();
    }
}
